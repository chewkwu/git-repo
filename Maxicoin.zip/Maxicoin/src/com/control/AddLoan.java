package com.control;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.brain.LoanBrain;
import com.info.Loans;

/**
 * Servlet implementation class AddLoan
 */
@WebServlet("/AddLoan")
public class AddLoan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddLoan() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
		Loans loan = new Loans();
		loan.setCustomerID(Integer.parseInt(request.getParameter("custid")));
		loan.setLoanAmount(Long.parseLong(request.getParameter("loanamt")));
		loan.setLoanType(request.getParameter("loantype"));
		loan.setLoanDuration(Integer.parseInt(request.getParameter("loanduration")));
		loan.setLoanDate(java.sql.Date.valueOf(request.getParameter("loandate")));
		LoanBrain brain = new LoanBrain();
		Loans loan2 = brain.createLoan(loan);
		request.setAttribute("loan", loan2);
		 RequestDispatcher rd = getServletContext().getRequestDispatcher("/regedLoan.jsp");
		rd.forward(request, response);	
		} catch(Exception e) {
			e.printStackTrace();
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/failLoan.jsp");
	        rd.forward(request, response);	
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
