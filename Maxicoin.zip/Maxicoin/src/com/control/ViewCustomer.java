package com.control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.brain.CustomerBrain;
import com.info.Customer;

/**
 * Servlet implementation class ViewCustomer
 */
@WebServlet("/ViewCustomer")
public class ViewCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        try {
		CustomerBrain custbrn = new CustomerBrain();
		Customer cust = custbrn.viewCustomer(Integer.parseInt(request.getParameter("custid")));
	    request.setAttribute("customer", cust);
	    RequestDispatcher rd = getServletContext().getRequestDispatcher("/regedCust.jsp");
	    rd.forward(request, response);	
        }catch(Exception e) {
        	e.printStackTrace();
        	RequestDispatcher rd = getServletContext().getRequestDispatcher("/viewCustFail.jsp");
    	    rd.forward(request, response);	
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
