package com.control;

import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import com.brain.CustomerBrain;
import com.info.Customer;

/**
 * Servlet implementation class RegCust
 */
@WebServlet("/RegCust")
@MultipartConfig
public class RegCust extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegCust() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType ("text/html");
		try {
			Customer cust = new Customer();
			cust.setTitle(request.getParameter("title"));
			cust.setFullname(request.getParameter("fullname"));
			cust.setHomeaddress(request.getParameter("homeaddress"));
			cust.setOccupation(request.getParameter("occupation"));
			cust.setBizaddress(request.getParameter("bizaddress"));
			cust.setPhonenumber(request.getParameter("phonenumber"));
			cust.setOfficephone(request.getParameter("officephone"));
			cust.setBvn(request.getParameter("bvn"));
			cust.setGender(request.getParameter("gender"));
			cust.setGuarantorname(request.getParameter("guarantorname"));
			final String path = request.getParameter("fullname");
			 final Part custpp = request.getPart("customerpassport");
			 final Part custiden = request.getPart("customerid");
			 final Part guardpp = request.getPart("guarantorpassport");
			 final Part guardiden = request.getPart("guarantorid");
			 final String custppname = "customerpassport";
			 final String custidenname = "customerid";
			 final String guardppname = "guarantorpassport";
			 final String guardidenname = "guarantorid";
			 
			 String applicationPath = getServletContext().getRealPath("");
			 String uploadPath = applicationPath + File.separator + path;
			 
			 File fileUploadDirectory = new File(uploadPath);
			 
			         if (!fileUploadDirectory.exists()) {
			             fileUploadDirectory.mkdirs();
			         }
        
			         custpp.write(uploadPath + File.separator + custppname);
			         cust.setCustomerPassport(uploadPath + File.separator + custppname);
			         custiden.write( uploadPath + File.separator + custidenname);
			         cust.setCustomerID(uploadPath + File.separator + custidenname);
			         guardpp.write(uploadPath + File.separator + guardppname);
			         cust.setGuarantorPassport(uploadPath + File.separator + guardppname);
			         guardiden.write(uploadPath + File.separator + guardidenname);
			         cust.setGuarantorID(uploadPath + File.separator + guardidenname);
			         
			
		        CustomerBrain custbrain = new CustomerBrain();
				int custID = custbrain.addCustomer(cust);
				Customer cust2 = custbrain.viewCustomer(custID);
		        request.setAttribute("customer", cust2);
		        RequestDispatcher rd = getServletContext().getRequestDispatcher("/regedCust.jsp");
		        rd.forward(request, response);	
		}catch(Exception e) {
			e.printStackTrace();
			 RequestDispatcher rd = getServletContext().getRequestDispatcher("/failCust.jsp");
		        rd.forward(request, response);
		}
		
		

}
}