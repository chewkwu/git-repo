package com.control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.brain.LoanBrain;
import com.info.Loans;

/**
 * Servlet implementation class ViewLoan
 */
@WebServlet("/ViewLoan")
public class ViewLoan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewLoan() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			LoanBrain lbrn = new LoanBrain();
			Loans loan = lbrn.viewLoan(Integer.parseInt(request.getParameter("loanid")));
			request.setAttribute("loan", loan);
		    RequestDispatcher rd = getServletContext().getRequestDispatcher("/regedLoan.jsp");
			rd.forward(request, response);
		}catch(Exception e) {
			 RequestDispatcher rd = getServletContext().getRequestDispatcher("/viewLoanFail.jsp");
			 rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
