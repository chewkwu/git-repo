package com.brain;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.info.Default;

public class DefaultBrain {

	public List<Default> allDefault() throws SQLException{
		List<Default> alldef = new ArrayList<>();
		 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM defaults";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    ResultSet rst = pst.executeQuery();
	    while(rst.next()) {
	    	Default def = new Default();
	    	def.setDefaultID(rst.getLong("DefaultID"));
	    	def.setLoanID(rst.getInt("LoanID"));
	    	def.setCustName(rst.getString("CustomerName"));
	    	def.setDefaultDate(rst.getDate("DefaultDate"));
	    	alldef.add(def);
	    }
	    conn.close();
	    return alldef;
	}
	public void createDefault(Default def) throws SQLException {
		 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "INSERT INTO defaults VALUES(?,?,?,?)";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setInt(1, Generator.trackCode());
	    pst.setInt(2, def.getLoanID());
	    pst.setString(3, def.getCustName());
	    pst.setDate(4, def.getDefaultDate());
	    pst.executeUpdate();
	    conn.close();
	}
	
	public List<Default> byDate(Date date) throws SQLException{
		List<Default> alldef = new ArrayList<>();
		 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM defaults WHERE DefaultDate =?";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setDate(1, date);
	    ResultSet rst = pst.executeQuery();
	    while(rst.next()) {
	    	Default def = new Default();
	    	def.setDefaultID(rst.getLong("DefaultID"));
	    	def.setLoanID(rst.getInt("LoanID"));
	    	def.setCustName(rst.getString("CustomerName"));
	    	def.setDefaultDate(rst.getDate("DefaultDate"));
	    	alldef.add(def);
	    }
	    conn.close();
	    return alldef;
	}
	public List<Default> byLoanID( int id) throws SQLException{
		List<Default> alldef = new ArrayList<>();
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM defaults WHERE LoanID =?";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setInt(1, id);
	    ResultSet rst = pst.executeQuery();
	    while(rst.next()) {
	    	Default def = new Default();
	    	def.setDefaultID(rst.getLong("DefaultID"));
	    	def.setLoanID(rst.getInt("LoanID"));
	    	def.setCustName(rst.getString("CustomerName"));
	    	def.setDefaultDate(rst.getDate("DefaultDate"));
	    	alldef.add(def);
	    }
	    conn.close();
	    return alldef;
	}
}
