package com.brain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.info.Payments;

public class PaymentBrain {

	public int registerPayment(Payments pay) throws SQLException {
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "INSERT INTO payment VALUES(?,?,?,?,?)";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    int id = Generator.trackCode();
	    pst.setInt(1, id);
		pst.setInt(2, pay.getLoanID());
		pst.setDate(3, pay.getPaymentDate());
		pst.setLong(4, pay.getPaymentAmount());
		pst.setString(5, pay.getPayStatus());
	    pst.executeUpdate();
	    conn.close();
	    return id;
	}
	
	public void updatePayment(long payID,  long payAmt) throws SQLException {
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM payment WHERE PaymentID = ?";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setLong(1, payID);
	    ResultSet rst = pst.executeQuery();
	    rst.next();
	    try {
	    LoanBrain lnbrn =  new LoanBrain();
	    lnbrn.updateLoanDetails(payAmt, rst.getInt("LoanID"));
	    } catch(Exception e) {
	    	e.printStackTrace();
	    }
	    String sql2 ="UPDATE payment SET PaymentStatus = ? WHERE PaymentID = ?";
		PreparedStatement pst2 = conn.prepareStatement(sql2);
		pst2.setString(1, "Paid");
		pst2.setLong(2, payID);
	    pst2.executeUpdate();
	    conn.close();
	}
	
	public Payments viewPayment(long id) throws SQLException {
		
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM payment WHERE PaymentID = ?";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setLong(1, id);
		ResultSet rst = pst.executeQuery();
		rst.next();
		Payments pay = new Payments();
		pay.setPaymentID(rst.getLong("PaymentID"));
		pay.setLoanID(rst.getInt("LoanID"));
		pay.setPaymentDate(rst.getDate("PaymentDate"));
		pay.setPaymentAmount(rst.getLong("PaymentAmount"));
		pay.setPayStatus(rst.getString("PaymentStatus"));
		conn.close();
		return pay;
	}
	
	public List<Payments> allPay() throws SQLException{
		List<Payments> allpay = new ArrayList<>();
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM payment ";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    ResultSet rst = pst.executeQuery();
	    while (rst.next()) {
	    	Payments pay = new Payments();
			pay.setPaymentID(rst.getLong("PaymentID"));
			pay.setLoanID(rst.getInt("LoanID"));
			pay.setPaymentDate(rst.getDate("PaymentDate"));
			pay.setPaymentAmount(rst.getLong("PaymentAmount"));
			pay.setPayStatus(rst.getString("PaymentStatus"));
			allpay.add(pay);
	    }
	    conn.close();
	    return allpay;
	}
	
	public List<Payments> payForLoan(int id) throws SQLException{
		List<Payments> allpay = new ArrayList<>();
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM payment WHERE LoanID =? ";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setInt(1, id);
	    ResultSet rst = pst.executeQuery();
	    while (rst.next()) {
	    	Payments pay = new Payments();
			pay.setPaymentID(rst.getLong("PaymentID"));
			pay.setLoanID(rst.getInt("LoanID"));
			pay.setPaymentDate(rst.getDate("PaymentDate"));
			pay.setPaymentAmount(rst.getLong("PaymentAmount"));
			pay.setPayStatus(rst.getString("PaymentStatus"));
			allpay.add(pay);
	    }
	    conn.close();
	    return allpay;
	}
	
}
