package com.brain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.info.Customer;

public class CustomerBrain {

	public int addCustomer(Customer customer) throws SQLException {
		
	    DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "INSERT INTO customer  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    int id = Generator.trackCode();
	    pst.setInt(1, id);
	    pst.setString(2, customer.getTitle());
	    pst.setString(3, customer.getFullname());
	    pst.setString(4, customer.getHomeaddress());
	    pst.setString(5, customer.getOccupation());
	    pst.setString(6, customer.getBizaddress());
	    pst.setString(7, customer.getPhonenumber());
	    pst.setString(8, customer.getOfficephone());
	    pst.setString(9, customer.getBvn());
		pst.setString(10, customer.getGender());
		pst.setString(11, customer.getGuarantorname());
		pst.setString(12, customer.getCustomerPassport());
		pst.setString(13, customer.getCustomerID());
		pst.setString(14, customer.getGuarantorPassport());
		pst.setString(15, customer.getGuarantorID());
		pst.executeUpdate();
		conn.close();
		return id;
	}
	
	public Customer viewCustomer(int id) throws SQLException {
		
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM customer WHERE CustomerID =?";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setInt(1, id);
	    ResultSet rst = pst.executeQuery();
		rst.next();
		Customer cust = new Customer();
		cust.setCustID(rst.getInt("CustomerID"));
		cust.setTitle(rst.getString("Title"));
		cust.setFullname(rst.getString("Fullname"));
		cust.setHomeaddress(rst.getString("HomeAddress"));
		cust.setOccupation(rst.getString("Occupation"));
		cust.setBizaddress(rst.getString("BizAddress"));
		cust.setPhonenumber(rst.getString("PhoneNumber"));
		cust.setOfficephone(rst.getString("OfficePhone"));
		cust.setBvn(rst.getString("Bvn"));
		cust.setGender(rst.getString("Gender"));
		cust.setGuarantorname(rst.getString("GuarantorName"));
		cust.setCustomerPassport(rst.getString("CustomerPassport"));
		cust.setCustomerID(rst.getString("CustomerIdentity"));
		cust.setGuarantorPassport(rst.getString("GuarantorPassport"));
		cust.setGuarantorID(rst.getString("GuarantorIdentity"));
		conn.close();
		return cust;
	}
	public List<Customer> allCust() throws SQLException{
		List<Customer> allCust = new ArrayList<>();
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM customer";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    ResultSet rst = pst.executeQuery();
	    while(rst.next()) {
	    	Customer cust = new Customer();
			cust.setCustID(rst.getInt("CustomerID"));
			cust.setTitle(rst.getString("Title"));
			cust.setFullname(rst.getString("Fullname"));
			cust.setHomeaddress(rst.getString("HomeAddress"));
			cust.setOccupation(rst.getString("Occupation"));
			cust.setBizaddress(rst.getString("BizAddress"));
			cust.setPhonenumber(rst.getString("PhoneNumber"));
			cust.setOfficephone(rst.getString("OfficePhone"));
			cust.setBvn(rst.getString("Bvn"));
			cust.setGender(rst.getString("Gender"));
			cust.setGuarantorname(rst.getString("GuarantorName"));
			cust.setCustomerPassport(rst.getString("CustomerPassport"));
			cust.setCustomerID(rst.getString("CustomerIdentity"));
			cust.setGuarantorPassport(rst.getString("GuarantorPassport"));
			cust.setGuarantorID(rst.getString("GuarantorIdentity"));
			allCust.add(cust);
	    }
	    conn.close();
	    return allCust;
	}
}
