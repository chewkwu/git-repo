package com.brain;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.info.Reminders;

public class ReminderBrain {

	public void createReminder(Reminders rem) throws SQLException {
		 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "INSERT INTO reminder VALUES(?,?,?,?)";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setInt(1, Generator.trackCode());
	    pst.setInt(2, rem.getLoanID());
	    pst.setString(3, rem.getReminderBody());
	    pst.setDate(4, rem.getReminderDate());
	    pst.executeUpdate();
	    conn.close();
	}
	
	public List<Reminders> byBate(Date date) throws SQLException{
		List<Reminders> allrem = new ArrayList<>();
		 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM reminder WHERE ReminderDate =?";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setDate(1, date);
	    ResultSet rst = pst.executeQuery();
	    while(rst.next()) {
	    	Reminders rem = new Reminders();
	    	rem.setReminderID(rst.getLong("ReminderID"));
	    	rem.setLoanID(rst.getInt("LoanID"));
	    	rem.setReminderBody(rst.getString("ReminderBody"));
	    	rem.setReminderDate(rst.getDate("ReminderDate"));
	    	allrem.add(rem);
	    }
	    conn.close();
	    return allrem;
	}
	public List<Reminders> byLoanID(int id) throws SQLException{
		List<Reminders> allrem = new ArrayList<>();
		 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM reminder WHERE LoanID =?";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setInt(1, id);
	    ResultSet rst = pst.executeQuery();
	    while(rst.next()) {
	    	Reminders rem = new Reminders();
	    	rem.setReminderID(rst.getLong("ReminderID"));
	    	rem.setLoanID(rst.getInt("LoanID"));
	    	rem.setReminderBody(rst.getString("ReminderBody"));
	    	rem.setReminderDate(rst.getDate("ReminderDate"));
	    	allrem.add(rem);
	    }
	    conn.close();
	    return allrem;
	}
}
