package com.brain;

import java.util.Random;

public class Generator {

	public static  int trackCode(){
        Random rand = new Random();
        int num = rand.nextInt(9000000) + (1000000);
        return num;
    }
	
}
