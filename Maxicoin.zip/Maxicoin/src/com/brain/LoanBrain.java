package com.brain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import com.info.Loans;
import com.info.Payments;

public class LoanBrain {

	public Loans createLoan(Loans loan) throws SQLException {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "INSERT INTO loans VALUES(?,?,?,?,?,?,?,?,?)";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    int id = Generator.trackCode();
	    pst.setInt(1, id);
	    pst.setInt(2, loan.getCustomerID());
	    pst.setLong(3, loan.getLoanAmount());
	    pst.setString(4, loan.getLoanType());
	    pst.setInt(5, loan.getLoanDuration());
	    pst.setDate(6, loan.getLoanDate());
	    long intr = loan.getLoanAmount()/10;
	    long ttintr = intr * loan.getLoanDuration();
	    long ttrpy = ttintr + loan.getLoanAmount();
	    long amtperpy = ttrpy/loan.getLoanDuration();
	    pst.setLong(7, ttrpy);
	    pst.setLong(8, amtperpy);
	    pst.setLong(9, ttrpy);
	    pst.executeUpdate();
	    if(loan.getLoanType().equalsIgnoreCase("Business")) {
        	long rptcount = loan.getLoanDuration()*4;
        	LocalDate ld = loan.getLoanDate().toLocalDate();
        	for (long i = 0; i< rptcount; i++) {
        		Payments pay = new Payments();
        		pay.setLoanID(id);
        		pay.setPaymentAmount(amtperpy);
        		ld = ld.plusWeeks(1);
        		pay.setPaymentDate(java.sql.Date.valueOf(ld));
        		pay.setPayStatus("Unpaid");
        		try {
        			PaymentBrain pybrn = new PaymentBrain();
        			pybrn.registerPayment(pay);
        		}catch(Exception e) {
        			e.printStackTrace();
        		}
        	}
        }
	    if(loan.getLoanType().equalsIgnoreCase("Salary")) {
        	long rptcount = loan.getLoanDuration();
        	LocalDate ld = loan.getLoanDate().toLocalDate();
        	for (long i = 0; i< rptcount; i++) {
        		Payments pay = new Payments();
        		pay.setLoanID(id);
        		pay.setPaymentAmount(amtperpy);
        		ld = ld.plusMonths(1);
        		pay.setPaymentDate(java.sql.Date.valueOf(ld));
        		pay.setPayStatus("Unpaid");
        		try {
        			PaymentBrain pybrn = new PaymentBrain();
        			pybrn.registerPayment(pay);
        		}catch(Exception e) {
        			e.printStackTrace();
        		}
        	}
        }
	    conn.close();
	    loan.setLoanID(id);
	    loan.setTotalRepayment(ttrpy);
	    loan.setAmtPerPay(amtperpy);
	    loan.setBalance(ttrpy);
	    return loan;
	}
	
	public List<Loans> allLoans() throws SQLException{
		List<Loans> allloans = new ArrayList<>();
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM loans";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    ResultSet rst = pst.executeQuery();
	    while(rst.next()) {
	    	Loans loan = new Loans();
	    	loan.setLoanID(rst.getInt("LoanID"));
	    	loan.setCustomerID(rst.getInt("CustomerID"));
	    	loan.setLoanAmount(rst.getLong("LoanAmount"));
	    	loan.setLoanType(rst.getString("LoanType"));
	    	loan.setLoanDuration(rst.getInt("LoanDuration"));
	    	loan.setLoanDate(rst.getDate("LoanDate"));
	    	loan.setTotalRepayment(rst.getLong("TotalRepayment"));
	    	loan.setAmtPerPay(rst.getLong("AmtPerPay"));
	    	loan.setBalance(rst.getLong("Balance"));
	    	allloans.add(loan);
	    }
	    conn.close();
	    return allloans;
	}
	public Loans viewLoan(int id) throws SQLException {
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql = "SELECT * FROM loans WHERE LoanID = ?";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setInt(1, id);
	    ResultSet rst =  pst.executeQuery();
	    rst.next();
        Loans loan = new Loans();
        loan.setLoanID(rst.getInt("LoanID"));
        loan.setCustomerID(rst.getInt("CustomerID"));
        loan.setLoanAmount(rst.getLong("LoanAmount"));
        loan.setLoanType(rst.getString("LoanType"));
        loan.setLoanDuration(rst.getInt("LoanDuration"));
        loan.setLoanDate(rst.getDate("LoanDate"));
        loan.setTotalRepayment(rst.getLong("TotalRepayment"));
        loan.setAmtPerPay(rst.getLong("AmtPerPay"));
        loan.setBalance(rst.getLong("Balance"));
        conn.close();
        return loan;
	}
	public void updateLoanDetails(long pay, int id) throws SQLException {
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    Connection conn = DriverManager.getConnection("jdbc:mysql:///maxicoin", "root", "java@1986");
	    String sql2 ="SELECT * FROM loans WHERE LoanID = ?";
	    PreparedStatement pst2 = conn.prepareStatement(sql2);
	    pst2.setInt(1, id);
	    ResultSet rst = pst2.executeQuery();
	    rst.next();
	    long newbal = rst.getLong("Balance") - pay;
	    String sql = "UPDATE loans SET Balance =? WHERE LoanID = ?";
	    PreparedStatement pst = conn.prepareStatement(sql);
	    pst.setLong(1, newbal);
	    pst.setInt(2, id);
	    pst.executeUpdate();
	    conn.close();
	}
}
