package com.info;

import java.sql.Date;

public class Reminders {

	private long reminderID;
	private int loanID;
	private String reminderBody;
	private Date reminderDate;
	
	public long getReminderID() {
		return reminderID;
	}
	public void setReminderID(long reminderID) {
		this.reminderID = reminderID;
	}
	public int getLoanID() {
		return loanID;
	}
	public void setLoanID(int loanID) {
		this.loanID = loanID;
	}
	public String getReminderBody() {
		return reminderBody;
	}
	public void setReminderBody(String reminderBody) {
		this.reminderBody = reminderBody;
	}
	public Date getReminderDate() {
		return reminderDate;
	}
	public void setReminderDate(Date reminderDate) {
		this.reminderDate = reminderDate;
	}
	
}
