package com.info;

import java.sql.Date;

public class Loans {

	private int loanID;
	private int customerID;
	private long loanAmount;
	private String loanType;
	private int loanDuration;
	private Date loanDate;
	private long totalRepayment;
	private long amtPerPay;
	private long balance;
	
	public int getLoanID() {
		return loanID;
	}
	public void setLoanID(int loanID) {
		this.loanID = loanID;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public long getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(long loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public int getLoanDuration() {
		return loanDuration;
	}
	public void setLoanDuration(int loanDuration) {
		this.loanDuration = loanDuration;
	}
	public Date getLoanDate() {
		return loanDate;
	}
	public void setLoanDate(Date loanDate) {
		this.loanDate = loanDate;
	}
	public long getTotalRepayment() {
		return totalRepayment;
	}
	public void setTotalRepayment(long totalRepayment) {
		this.totalRepayment = totalRepayment;
	}
	public long getAmtPerPay() {
		return amtPerPay;
	}
	public void setAmtPerPay(long amtPerPay) {
		this.amtPerPay = amtPerPay;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	
}
