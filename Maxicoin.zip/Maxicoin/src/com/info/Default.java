package com.info;

import java.sql.Date;

public class Default {

	private long defaultID;
	private int loanID;
	private String custName;
	private Date defaultDate;
	
	public long getDefaultID() {
		return defaultID;
	}
	public void setDefaultID(long defaultID) {
		this.defaultID = defaultID;
	}
	public int getLoanID() {
		return loanID;
	}
	public void setLoanID(int loanID) {
		this.loanID = loanID;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Date getDefaultDate() {
		return defaultDate;
	}
	public void setDefaultDate(Date defaultDate) {
		this.defaultDate = defaultDate;
	}
	
}
