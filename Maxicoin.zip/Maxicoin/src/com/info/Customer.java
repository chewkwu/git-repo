package com.info;

public class Customer {

	private int custID;
	private String title;
	private String fullname;
	private String homeaddress;
	private String occupation;
	private String bizaddress;
	private String phonenumber;
	private String officephone;
	private String bvn;
	private String gender;
	private String guarantorname;
	private String customerPassport;
	private String customerID;
	private String guarantorPassport;
	private String guarantorID;
	
	
	public int getCustID() {
		return custID;
	}
	public void setCustID(int custID) {
		this.custID = custID;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getHomeaddress() {
		return homeaddress;
	}
	public void setHomeaddress(String homeaddress) {
		this.homeaddress = homeaddress;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getBizaddress() {
		return bizaddress;
	}
	public void setBizaddress(String bizaddress) {
		this.bizaddress = bizaddress;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getOfficephone() {
		return officephone;
	}
	public void setOfficephone(String officephone) {
		this.officephone = officephone;
	}
	public String getBvn() {
		return bvn;
	}
	public void setBvn(String bvn) {
		this.bvn = bvn;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getGuarantorname() {
		return guarantorname;
	}
	public void setGuarantorname(String guarantorname) {
		this.guarantorname = guarantorname;
	}
	public String getCustomerPassport() {
		return customerPassport;
	}
	public void setCustomerPassport(String customerPassport) {
		this.customerPassport = customerPassport;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getGuarantorPassport() {
		return guarantorPassport;
	}
	public void setGuarantorPassport(String guarantorPassport) {
		this.guarantorPassport = guarantorPassport;
	}
	public String getGuarantorID() {
		return guarantorID;
	}
	public void setGuarantorID(String guarantorID) {
		this.guarantorID = guarantorID;
	}
	
}
