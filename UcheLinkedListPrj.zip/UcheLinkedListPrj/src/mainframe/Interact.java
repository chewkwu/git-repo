package mainframe;

import java.util.Scanner;

public class Interact {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		MyLinkedList mylist = new MyLinkedList();
		System.out.println("Demo, Select an operation to perform : ");
		char ch;
		do {
			
			System.out.println("1. Add to List");
			System.out.println("2. Remove from Tail");
			System.out.println("3. Prune size of List removing the Excess greater Than Specified Value");
			System.out.println("4. Show size");
			int choice = input.nextInt();
			switch(choice) {
			case 1 :
				System.out.println("Enter an Integer to Insert : ");
				String result3 = mylist.append(input.nextInt());
				System.out.println(result3);
				break;
			case 2 :
				int result4 = mylist.tailOff();
				System.out.println("The tail has been pruned, the size on the list is now : "+ result4);
				break;
			case 3 :
				System.out.println("Enter an Integer to be set as new Size of List : ");
				String res5 = mylist.clearFrom(input.nextInt());
				System.out.println(res5);
			    break;
			case 4 :
				int six = mylist.getSize();
				System.out.println("Size of list Currently is : "+ six);
			    break;
			default :
				System.out.println("Wrong Entry");
				break;
			}
			System.out.println("Do you want to continue, Type : y or n ");
			ch =input.next().charAt(0);
		}while(ch == 'Y' || ch == 'y');
		input.close();
	}

	
}
