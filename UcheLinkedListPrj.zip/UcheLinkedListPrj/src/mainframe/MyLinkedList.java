package mainframe;

public class MyLinkedList {

	protected Node start;
	protected Node end;
	int size;
	
	public MyLinkedList() {
		start = null;
		end = null;
		size = 0;
	}
	
		public String append(int value) {
		Node last = new Node(value,null);
		size++ ;
		if(start == null) {
			start = last;
			end = start;
		}else {
			last.setLink(start);
			start = last;
		}
		return "Value : " + end.getData() + " Successfully entered, List has a size of : " + size;
	}
	public int tailOff() {
		Node sb = null;
	    while(start.getLink()==null) {
	    	sb = start.getLink();
	    }
		sb.setData(0);
		sb.setLink(null);
		size--;
		return size;
	}
	
	public String clearFrom(int boundry) {
	  int i = getSize() - boundry;
	  int x = 0;
	  while( x < i ) {
		  Node sb = start.getLink();
		  Node sb2 = sb.getLink();
		  start = sb;
		  start.setLink(sb2);
		  size-- ;
		  x++;
	  }
	  return "List now has a size of : " + size ;
	}
	
	public int getSize() {
		return size;
	}
	
}
